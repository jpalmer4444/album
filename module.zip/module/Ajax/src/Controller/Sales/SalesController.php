<?php

namespace Ajax\Controller\Sales;

use Zend\Mvc\Controller\AbstractRestfulController;

/**
 * Description of SalesController
 *
 * @author jasonpalmer
 */
class SalesController extends AbstractRestfulController{
    
    
    
}
