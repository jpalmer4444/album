<?php
/**
 */

namespace Sales\Controller;

use Application\Module;
use Application\Service\LoggingService;
use Application\Service\RestServiceInterface;
use Login\Model\MyAuthStorage;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class ItemsController extends AbstractActionController
{
    
    const ID = "jpalmer";
    const PASSWORD = "goodbass";
    const OBJECT = "customerlistitems";
    
    protected $restService;

    protected $logger;
    
    protected $myauthstorage;
    
    protected $byskuhost;
    
    //https://svc.ffmalpha.com/bySKU.php?id=jpalmer&pw=goodbass&object=customerlistitems&customerid=735
    
    public function __construct($container){
        $this->restService = $container->get('RestService');
        $this->logger = $container->get('LoggingService');
        $this->myauthstorage = $container->get('Login\Model\MyAuthStorage');
        $this->byskuhost = $container->get('config')['pricing_config']['by_sku_host'];
    }
    
    public function indexAction()
    {
        $this->logger->info('Retrieving ' . ItemsController::OBJECT . '.');
        $customerid = $this->params()->fromQuery('customerid');
        $params = [
            "id" => SalesController::ID,
            "pw" => SalesController::PASSWORD,
            "object" => ItemsController::OBJECT,
            "customerid" => $customerid
        ];
        $method = Module::BYSKU_METHOD;
        $json = $this->rest($this->byskuhost, $method, $params);
        if(array_key_exists(ItemsController::OBJECT, $json)){
            $this->logger->debug('Retrieved ' . count($json[ItemsController::OBJECT]) . ' ' . ItemsController::OBJECT . '.');
        }else{
            $this->logger->debug('No ' . ItemsController::OBJECT . ' items found.');
        }
        return new ViewModel(array(
            "json" => $json
        ));
    }
    
    public function rest($url, $method = "GET", $params = []) {
        return $this->restService->rest($url, $method, $params);
    }
    
}
